#include "/lib/misc/alexCavesBiomes.glsl"

vec3 GetMinimumLighting(float lightmapYM) {
    #if !defined END && CAVE_LIGHTING > 0
        vec3 minLighting = vec3(0.005625 + vsBrightness * 0.043);
        #if CAVE_LIGHTING != 100
            #define CAVE_LIGHTING_M CAVE_LIGHTING * 0.01
            minLighting *= CAVE_LIGHTING_M;
        #endif
        #ifdef ALEXSCAVES_CAVE_LIGHTING
            int acBiome = GetAlexsCavesBiomeID();
            vec3 caveAmbientTint = acBiome > 0
                ? mix(vec3(0.45, 0.475, 0.6), GetAlexsCavesAmbientColor(acBiome), ALEXSCAVES_CAVE_LIGHTING_STRENGTH * 0.01)
                : vec3(0.45, 0.475, 0.6);
            minLighting *= caveAmbientTint;
            minLighting *= GetAlexsCavesLightMultiplier(acBiome);
            minLighting += GetAlexsCavesDeepsightAmbient();
        #else
            minLighting *= vec3(0.45, 0.475, 0.6);
        #endif
        minLighting *= 1.0 - lightmapYM;
    #else
        vec3 minLighting = vec3(0.0);
    #endif

    minLighting += nightVision * vec3(0.5, 0.5, 0.75);

    return max(minLighting, vec3(0.0));
}
